//
//  ViewController.swift
//  Ex2
//
//  Created by Usuario invitado on 29/10/18.
//  Copyright © 2018 UNAM. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
    }
    //Codigo para aumentar reservaciones de hoteles
    var acumuluadorHoteles = 0
    //Boton de hotel Emporio Zacatecas
    @IBAction func EZB(_ sender: UISwitch)
    {
        if sender.isOn
        {
            
            print("Seleccion correcta")
            //acumuladorHoteles= acumuladorHoteles+1
        }
        else{
            //print("Respuesta incorrecta")
        }
        
    }
    //Boton de hotel Mision Argento
    @IBAction func MAB(_ sender: UISwitch)
    {
        if sender.isOn{
            
            print("Seleccion correcta")
            //acumuladorHoteles= acumuladorHoteles+1
        }
        else
        {
        //    print("Respuesta incorrecta")
        }
        
    }
    //Boton de hotel Santa Rita
    @IBAction func SRB(_ sender: UISwitch) {
        if sender.isOn{
            
            print("Seleccion correcta")
            //acumuladorHoteles= acumuladorHoteles+1
        }
        else{
            //print("Respuesta incorrecta")
        }
        
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBAction func boton1(_ sender: UISwitch) {
        
        if sender.isOn{
            
           print("respuesta correcta")
            
        }
        else{
            print("Respuesta incorrecta")
        }
      
    }
    
}

