//
//  Sign.swift
//  Piedra_Papel_Tijera
//
//  Created by Guest User on 2/10/18.
//  Copyright © 2018 UNAM. All rights reserved.
//
import GameplayKit

let randomChoice = GKRandomDistribution(lowestValue: 0, highestValue: 2)
func randomSign() -> Sign
{​      let sign = randomChoice.nextInt();
    if sign == 0 {​         return .rock​     }
        else if sign == 1
{ return .paper
            
        }
        else
        {
            return .scissors
            
        }
    
}

import Foundation
