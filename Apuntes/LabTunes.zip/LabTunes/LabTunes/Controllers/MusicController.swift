//
//  MusicController.swift
//  LabTunes
//
//  Created by Usuario invitado on 11/21/18.
//  Copyright © 2018 Usuario invitado. All rights reserved.
//

import Foundation
class MusicController {
    static var urlSesion = URLSession(configuration: .default)
    static func fetchMusic(search: String, completion: @escaping ([Song]?)->Void) //song
    {
    // static func fetchMusic(){
        guard let url = URL(string: "https://itunes.apple.com/search/media=music&identity=song&term="+search)
            else {return}
        let dataTask = urlSesion.dataTask(with: url){(data, response, error) in if let error = error{
            debugPrint("Error in dataTask: \(error.localizedDescription)")
            }
            guard let httpResponse = response as? HTTPURLResponse, (200 ... 299).contains(httpResponse.statusCode)else{
                debugPrint("Error in httpReponse, code out range between 200 ... 299")
                completion(nil)
                return
            }
            guard let data = data else {
                debugPrint("No data")
                completion(nil)
                return
            }
        //print (data)
        guard let songList = try? JSONDecoder().decode(Song.self, from: data)
            else {
            debugPrint("Can't decode the data")
            completion(nil)
            return
            }
           //debugPrint(songList)
           completion(songList.results)//Array de canciones
        //completion(songList) //Regresa todo el elemento de songList
        //return songList
        }
    dataTask.resume()
    //return songList
    }
    
}
