import UIKit
/*
import PlaygroundSupport
PlaygroundPage.current.needsIndefiniteExecution = true
//Solo se añade cuando el playground no realiza nada
*/
//---------------------------------------------------------------------------------//
//Creación de método URL Extension
extension URL
{
    func withQueries(_ queries: [String:String]) -> URL?
    {
        var components = URLComponents(url: self, resolvingAgainstBaseURL: true)
        components?.queryItems = queries.map
            {
                URLQueryItem(name: $0.0, value: $0.1)
            }
        return components?.url
    }
}
//-----------------------------------------------------------------------------------//
//let url = URL(string: "https://apod.nasa.gov/apod/image/1811/CaveNebula_Ayoub_960.jpg")!
let query: [String:String] = ["api_key":"5qa2LkgXiN6bvaTY8yR3bGO2h72kJWVwoNMkF5kI", "date":"2011-07-13"]
// Crea esto:
//https://apod.nasa.gov/apod/apod?api_key=5qa2LkgXiN6bvaTY8yR3bGO2h72kJWVwoNMkF5kI&&date=2011-07-13
//

struct NasaPhoto: Codable
{
    var date: String
    var titulo: String
    var explanation: String
    var url: String
    enum CodingKeys: String,CodingKeys
    {
        case date
        case titulo = "title"
        case explanation
        case url
    }
}

let baseUrl = URL(string: "https://api.nasa.gov/planetary/apod")!
//let query: [String:String] = ["api_key":"5qa2LkgXiN6bvaTY8yR3bGO2h72kJWVwoNMkF5kI"]
let url = baseUrl.withQueries(query)!

let task = URLSession.shared.dataTask(with: url) { (data, response, error) in
    if let data = data,
     //configurando tarea de solicitud, no es request
        //print(data as? NSData)
        let string = String(data: data, encoding: .utf8){
        print(string)
        
    }
}
task.resume() //Mandar a llamar la tarea


var str = "Hello, playground"
