import UIKit
/*
import PlaygroundSupport
PlaygroundPage.current.needsIndefiniteExecution = true
//Solo se añade cuando el playground no realiza nada
*/

let url = URL(string: "https://www.apple.com")!
let task = URLSession.shared.dataTask(with: url) { (data, response, error) in
    if let data = data
    { //configurando tarea de solicitud, no es request
        print(data as? NSData)
        let string = String(data: data, encoding: .utf8){
        print(string)
        }
    }
}
task.resume() //Mandar a llamar la tarea


var str = "Hello, playground"
