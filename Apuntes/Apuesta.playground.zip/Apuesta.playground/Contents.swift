//: Playground - noun: a place where people can play

import UIKit

var str = "Hello, playground"
enum Suit
{
    case spades, hearts, diamonds, clubs
    var rank: Int
    {
        switch self
        {
        case .spades: return 4
        case .hearts: return 3
        case .diamonds: return 2
        case .clubs: return 1
        }
    }
    var symbol: String
    {
        switch self
        {
        case .spades:
            return "iconspades"
        case .hearts:
            return "iconheart"
        case .diamonds:
            return "icondiamond"
        case .clubs:
            return "iconclubs"
        }
    }
    func beats (_ OtherSuit: Suit) -> Bool
    {
        return self.rank > OtherSuit.rank
    }
}
let oneSuit = Suit.hearts
let otherSuit = Suit.clubs
//: oneSuit.symbol
