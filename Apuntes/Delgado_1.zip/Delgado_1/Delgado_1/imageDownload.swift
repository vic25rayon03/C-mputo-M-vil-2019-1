//
//  imageDownload.swift
//  Delgado_1
//
//  Created by Usuario invitado on 22/10/18.
//  Copyright © 2018 UNAM. All rights reserved.
//
import UIKit
import Foundation
class ImageDownload
    {
    var imageUrl: String
    var image: UIImage?
    var view: ViewController
    init(imageUrl:String, view:ViewController)
    {
        self.imageUrl = imageUrl
        self.view = view
    }
    func downloadImage()
    {
        // Aqui voy a hacer todo para bajar la imagen
        DispatchQueue.global(qos: DispatchQoS.QoSClass.background).async {
            guard
                //let imageUrlUnwrapped = URL(string: self.imageUrl),
                let imageUrl = URL(string: self.imageUrl),
                let imageData = NSData(contentsOf: imageUrl),
                let image = UIImage(data: imageData as Data) else {return}
            
        }
        //DispatchQoS.QoSClass.background
    }
    func didDownloadImage()
    {
        // Que hago una vez que se bajo
    }
}
