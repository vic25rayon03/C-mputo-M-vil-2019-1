//
//  ViewController.swift
//  Delgado_1
//
//  Created by Usuario invitado on 22/10/18.
//  Copyright © 2018 UNAM. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var imageView: UIImageView!
    @IBOutlet weak var activityIndicatior: UIActivityIndicatorView!
    @IBOutlet weak var titulo_1: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()
        
        imageView.isHidden = true
        activityIndicatior.isHidden = true
        let _: String = "https://www.nasa.gov/sites/default/files/thumbnails/image/14797031062_4cbe0f218f_o.jpg"
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

