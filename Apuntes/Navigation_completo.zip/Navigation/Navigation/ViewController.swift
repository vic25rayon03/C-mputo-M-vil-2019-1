//
//  ViewController.swift
//  Navigation
//
//  Created by Usuario invitado on 24/9/18.
//  Copyright © 2018 Usuario invitado. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var switchSegue: UISwitch!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    @IBAction func segueButton(_ sender: Any) {
    }
    @IBAction func segueButton(_ sender: Any) {
        if switchSegue.isOn {
            performSegue(withIdentifier: "Green", sender: nil)
        }
        else{
        performSegue(withIdentifier: "Yellow", sender: nil)
    }
        func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
        func unwindToRed(unwindSegue: UIStoryboardSegue)
    {
        
    }
    //  Ejercicio 1
    // se eliminaron las conexiones
      //  func prepare(for segue: UIStoryboardSegue, sender: Any?) {
    }}


