struct MyQuestionAnswerer {
    func responseTo(question: String) -> String {
        // PENDIENTE: Escribir una respuesta 
        return "?"
    }
}
