//: Playground - noun: a place where people can play

import UIKit

var str = "Hello, playground"
enum Suit
{
    case one, two, three, four, five, six, seven, eight, nine, ten, eleven, twelve, thirteen, fourteen, fifteen, sixteen, seventeen, eighteen, nineteen, twenty
    var rank: Int
    {
        switch self
        {
        case .one: return 4
        case .two: return 3
        case .three: return 2
        case .four: return 1
        case .five: return 5
        case .six: return 6
        case .seven: return 7
        case .eight: return 8
        case .nine: return 9
        case .ten: return 10
        case .eleven: return 11
        case .twelve: return 12
        case .thirteen: return 13
        case .fourteen: return 14
        case .fifteen: return 15
        case .sixteen: return 16
        case .seventeen: return 17
        case .eighteen: return 18
        case .nineteen: return 19
        case .twenty: return 20
        }
    }
    var symbol: String
    {
        switch self
        {
        case .one:
            return "1"
        case .two:
            return "2"
        case .three:
            return "3"
        case .four:
            return "4"
        case .five:
            return "5"
        case .six:
            return "6"
        case .seven:
            return "7"
        case .eight:
            return "8"
        case .nine:
            return "9"
        case .ten:
            return "10"
        case .eleven:
            return "11"
        case .twelve:
            return "12"
        case .thirteen:
            return "13"
        case .fourteen:
            return "14"
        case .fifteen:
            return "15"
        case .sixteen:
            return "16"
        case .seventeen:
            return "17"
        case .eighteen:
            return "18"
        case .nineteen:
            return "19"
        case .twenty:
            return "20"
        }
    }
    func beats (_ OtherSuit: Suit) -> Bool
    {
        return self.rank > OtherSuit.rank
    }
}
let randomSuit = Suit.randomElement()
let otherSuit = Suit.two
